import React from 'react';
import { Car, MapPin, Clock, Phone, Shield, Droplets, Sparkles, Timer, Calendar, Star, Image as ImageIcon } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="relative h-[600px]">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?auto=format&fit=crop&q=80&w=2000")',
          }}
        >
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
        
        <nav className="relative z-10 container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-white">
              <Car className="h-8 w-8" />
              <span className="text-2xl font-bold">АвтоБлеск</span>
            </div>
            <div className="flex items-center space-x-8 text-white">
              <a href="#services" className="hover:text-blue-400 transition">Услуги</a>
              <a href="#schedule" className="hover:text-blue-400 transition">Расписание</a>
              <a href="#gallery" className="hover:text-blue-400 transition">Галерея</a>
              <a href="#reviews" className="hover:text-blue-400 transition">Отзывы</a>
              <a href="#contacts" className="hover:text-blue-400 transition">Контакты</a>
              <a href="tel:+73433000000" className="flex items-center space-x-2 bg-blue-600 px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                <Phone className="h-4 w-4" />
                <span>+7 (343) 300-00-00</span>
              </a>
            </div>
          </div>
        </nav>

        <div className="relative z-10 container mx-auto px-6 pt-32">
          <h1 className="text-5xl font-bold text-white mb-6">
            Профессиональная автомойка<br />в Екатеринбурге
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl">
            Качественная мойка вашего автомобиля с использованием современного оборудования и профессиональной химии
          </p>
          <div className="flex space-x-4">
            <a href="#services" className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition">
              Наши услуги
            </a>
            <a href="#contacts" className="bg-white text-blue-900 px-8 py-3 rounded-lg hover:bg-gray-100 transition">
              Записаться
            </a>
          </div>
        </div>
      </header>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-gray-50">
              <Shield className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Гарантия качества</h3>
              <p className="text-gray-600">Используем только профессиональные средства и оборудование</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-gray-50">
              <Timer className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Быстрое обслуживание</h3>
              <p className="text-gray-600">Средняя длительность мойки - 30-40 минут</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-gray-50">
              <Sparkles className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Комплексный уход</h3>
              <p className="text-gray-600">От простой мойки до полной химчистки салона</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Наши услуги</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <Droplets className="h-8 w-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{service.name}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <p className="text-2xl font-bold text-blue-600">от {service.price} ₽</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Schedule */}
      <section id="schedule" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Расписание работы</h2>
          <div className="max-w-3xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 p-8 rounded-lg">
                <div className="flex items-center mb-6">
                  <Calendar className="h-8 w-8 text-blue-600 mr-4" />
                  <h3 className="text-xl font-semibold">Рабочие дни</h3>
                </div>
                <div className="space-y-4">
                  {schedule.workdays.map((day, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-gray-600">{day.days}</span>
                      <span className="font-semibold">{day.hours}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-gray-50 p-8 rounded-lg">
                <div className="flex items-center mb-6">
                  <Clock className="h-8 w-8 text-blue-600 mr-4" />
                  <h3 className="text-xl font-semibold">Перерывы</h3>
                </div>
                <div className="space-y-4">
                  <p className="text-gray-600">Технический перерыв:</p>
                  <p className="font-semibold">14:00 - 15:00</p>
                  <p className="text-gray-600 mt-4">Санитарный час:</p>
                  <p className="font-semibold">22:00 - 23:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Галерея работ</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {gallery.map((item, index) => (
              <div key={index} className="relative group overflow-hidden rounded-lg">
                <img 
                  src={item.url} 
                  alt={item.description}
                  className="w-full h-64 object-cover transform transition-transform group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <p className="text-white text-center px-4">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section id="reviews" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Отзывы клиентов</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                      <Star className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold">{review.name}</h4>
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < review.rating ? 'text-yellow-400' : 'text-gray-300'
                          }`}
                          fill={i < review.rating ? 'currentColor' : 'none'}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">{review.text}</p>
                <p className="text-sm text-gray-500 mt-2">{review.date}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contacts" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold mb-6">Контакты</h2>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <MapPin className="h-6 w-6 text-blue-600" />
                  <p>ул. Ленина, 1, Екатеринбург</p>
                </div>
                <div className="flex items-center space-x-4">
                  <Phone className="h-6 w-6 text-blue-600" />
                  <p>+7 (343) 300-00-00</p>
                </div>
                <div className="flex items-center space-x-4">
                  <Clock className="h-6 w-6 text-blue-600" />
                  <p>Ежедневно с 8:00 до 22:00</p>
                </div>
              </div>
            </div>
            <div>
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2181.7903338266226!2d60.59394731594!3d56.83892798086!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x43c16e9f95905b5b%3A0x2c6b0e4e937b7a23!2z0YPQuy4g0JvQtdC90LjQvdCwLCAxLCDQldC60LDRgtC10YDQuNC90LHRg9GA0LMsINCh0LLQtdGA0LTQu9C-0LLRgdC60LDRjyDQvtCx0LsuLCA2MjAwMTQ!5e0!3m2!1sru!2sru!4v1635000000000!5m2!1sru!2sru"
                className="w-full h-[300px] rounded-lg"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Car className="h-6 w-6" />
              <span className="text-xl font-bold">АвтоБлеск</span>
            </div>
            <p className="text-gray-400">© 2024 АвтоБлеск. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

const services = [
  {
    name: 'Экспресс-мойка',
    description: 'Быстрая мойка кузова с шампунем и сушка',
    price: '400',
  },
  {
    name: 'Комплексная мойка',
    description: 'Мойка кузова, колес, влажная уборка салона',
    price: '800',
  },
  {
    name: 'Химчистка салона',
    description: 'Глубокая очистка всех элементов салона',
    price: '3000',
  },
  {
    name: 'Полировка кузова',
    description: 'Восстановление блеска и защита лакокрасочного покрытия',
    price: '5000',
  },
  {
    name: 'Нанокерамика',
    description: 'Долговременная защита кузова керамическим покрытием',
    price: '15000',
  },
  {
    name: 'Детейлинг',
    description: 'Полный комплекс услуг по уходу за автомобилем',
    price: '20000',
  },
];

const schedule = {
  workdays: [
    { days: 'Понедельник - Пятница', hours: '8:00 - 22:00' },
    { days: 'Суббота', hours: '9:00 - 21:00' },
    { days: 'Воскресенье', hours: '9:00 - 20:00' },
  ],
};

const gallery = [
  {
    url: 'https://images.unsplash.com/photo-1605164599901-db99a5c38e82?auto=format&fit=crop&q=80&w=1200',
    description: 'Мойка премиум автомобилей',
  },
  {
    url: 'https://images.unsplash.com/photo-1601362840469-51e4d8d58785?auto=format&fit=crop&q=80&w=1200',
    description: 'Химчистка салона',
  },
  {
    url: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=1200',
    description: 'Полировка кузова',
  },
  {
    url: 'https://images.unsplash.com/photo-1607860108855-64acf2078ed9?auto=format&fit=crop&q=80&w=1200',
    description: 'Нанесение защитного покрытия',
  },
  {
    url: 'https://images.unsplash.com/photo-1616803824305-a07cfb91d5b2?auto=format&fit=crop&q=80&w=1200',
    description: 'Детейлинг экстерьера',
  },
  {
    url: 'https://images.unsplash.com/photo-1601362840469-51e4d8d58785?auto=format&fit=crop&q=80&w=1200',
    description: 'Комплексный уход',
  },
];

const reviews = [
  {
    name: 'Александр М.',
    rating: 5,
    text: 'Отличный сервис! Машину помыли быстро и качественно. Особенно порадовала химчистка салона - как новый!',
    date: '15 марта 2024',
  },
  {
    name: 'Елена К.',
    rating: 5,
    text: 'Регулярно обслуживаюсь здесь. Нравится профессионализм сотрудников и внимание к деталям.',
    date: '10 марта 2024',
  },
  {
    name: 'Дмитрий С.',
    rating: 4,
    text: 'Хорошая мойка, приятные цены. Единственное - иногда приходится подождать в очереди.',
    date: '5 марта 2024',
  },
];

export default App;